"""
SH HOST — simple multi-user static site hosting panel with an admin panel.

Run locally:
    pip install -r requirements.txt
    python app.py
    -> open http://127.0.0.1:5000

Admin panel:
    http://127.0.0.1:5000/admin
    default login: admin / changeme123   (CHANGE THIS AFTER FIRST LOGIN — see README.txt)

Deploy: push this folder to a GitHub repo, then deploy on Render / Railway / PythonAnywhere
(see README.txt for step-by-step instructions).
"""

import os
import re
import sqlite3
import secrets
import shutil
import string
import zipfile
from datetime import datetime

from flask import (
    Flask, request, session, redirect, url_for, render_template,
    send_from_directory, jsonify, g, abort
)
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename

BASE_DIR = os.path.abspath(os.path.dirname(__file__))
DB_PATH = os.path.join(BASE_DIR, "sh_host.db")
UPLOAD_DIR = os.path.join(BASE_DIR, "uploads")
ALLOWED_UPLOAD_EXT = {".html", ".htm", ".zip"}

os.makedirs(UPLOAD_DIR, exist_ok=True)

app = Flask(__name__)
# IMPORTANT: change this secret key before putting the site online for real.
app.config["SECRET_KEY"] = os.environ.get("SH_HOST_SECRET", secrets.token_hex(32))
app.config["MAX_CONTENT_LENGTH"] = 20 * 1024 * 1024  # 20 MB upload limit


# --------------------------------------------------------------------------
# Database helpers
# --------------------------------------------------------------------------

def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys = ON")
    return g.db


@app.teardown_appcontext
def close_db(exception=None):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def init_db():
    db = sqlite3.connect(DB_PATH)
    db.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            is_admin INTEGER NOT NULL DEFAULT 0,
            created_at TEXT NOT NULL
        )
    """)
    db.execute("""
        CREATE TABLE IF NOT EXISTS sites (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            owner_id INTEGER NOT NULL,
            sitename TEXT UNIQUE NOT NULL,
            created_at TEXT NOT NULL,
            FOREIGN KEY (owner_id) REFERENCES users(id) ON DELETE CASCADE
        )
    """)
    db.execute("""
        CREATE TABLE IF NOT EXISTS settings (
            key TEXT PRIMARY KEY,
            value TEXT NOT NULL
        )
    """)
    defaults = {
        "site_name": "SH HOST",
        "logo_url": "",
        "youtube_url": "https://youtube.com/",
        "tiktok_url": "https://tiktok.com/",
        "facebook_url": "https://facebook.com/",
    }
    for k, v in defaults.items():
        db.execute("INSERT OR IGNORE INTO settings (key, value) VALUES (?, ?)", (k, v))

    # Default admin account — change the password after first login.
    existing_admin = db.execute("SELECT id FROM users WHERE is_admin = 1").fetchone()
    if not existing_admin:
        db.execute(
            "INSERT INTO users (username, password_hash, is_admin, created_at) VALUES (?, ?, 1, ?)",
            ("admin", generate_password_hash("changeme123"), datetime.utcnow().isoformat()),
        )
    db.commit()
    db.close()


def get_settings():
    db = get_db()
    rows = db.execute("SELECT key, value FROM settings").fetchall()
    return {r["key"]: r["value"] for r in rows}


# --------------------------------------------------------------------------
# Auth helpers
# --------------------------------------------------------------------------

def current_user():
    uid = session.get("user_id")
    if not uid:
        return None
    return get_db().execute("SELECT * FROM users WHERE id = ?", (uid,)).fetchone()


def login_required(view):
    def wrapped(*args, **kwargs):
        if not current_user():
            return redirect(url_for("index"))
        return view(*args, **kwargs)
    wrapped.__name__ = view.__name__
    return wrapped


def admin_required(view):
    def wrapped(*args, **kwargs):
        user = current_user()
        if not user or not user["is_admin"]:
            return redirect(url_for("admin_login"))
        return view(*args, **kwargs)
    wrapped.__name__ = view.__name__
    return wrapped


def clean_sitename(raw):
    raw = (raw or "").lower().strip()
    raw = re.sub(r"[^a-z0-9-]", "", raw)
    raw = re.sub(r"-{2,}", "-", raw).strip("-")
    return raw[:30]


def random_username():
    chars = string.ascii_lowercase + string.digits
    return "u" + "".join(secrets.choice(chars) for _ in range(12))


def random_password():
    chars = string.ascii_letters + string.digits + "!@#$%"
    return "".join(secrets.choice(chars) for _ in range(16))


# --------------------------------------------------------------------------
# Public site
# --------------------------------------------------------------------------

@app.route("/")
def index():
    user = current_user()
    sites = []
    if user:
        sites = get_db().execute(
            "SELECT * FROM sites WHERE owner_id = ? ORDER BY created_at DESC", (user["id"],)
        ).fetchall()
    return render_template("index.html", user=user, sites=sites, settings=get_settings())


@app.route("/register", methods=["POST"])
def register():
    username = (request.form.get("username") or "").strip()
    password = request.form.get("password") or ""
    if len(username) < 3 or len(password) < 6:
        return jsonify({"ok": False, "error": "Username 3+ chars, password 6+ chars."}), 400

    db = get_db()
    exists = db.execute("SELECT id FROM users WHERE username = ?", (username,)).fetchone()
    if exists:
        return jsonify({"ok": False, "error": "Username already taken."}), 400

    db.execute(
        "INSERT INTO users (username, password_hash, is_admin, created_at) VALUES (?, ?, 0, ?)",
        (username, generate_password_hash(password), datetime.utcnow().isoformat()),
    )
    db.commit()
    user = db.execute("SELECT * FROM users WHERE username = ?", (username,)).fetchone()
    session["user_id"] = user["id"]
    return jsonify({"ok": True})


@app.route("/login", methods=["POST"])
def login():
    username = (request.form.get("username") or "").strip()
    password = request.form.get("password") or ""
    db = get_db()
    user = db.execute("SELECT * FROM users WHERE username = ?", (username,)).fetchone()
    if not user or not check_password_hash(user["password_hash"], password):
        return jsonify({"ok": False, "error": "Wrong username or password."}), 401
    session["user_id"] = user["id"]
    return jsonify({"ok": True, "is_admin": bool(user["is_admin"])})


@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("index"))


@app.route("/upload", methods=["POST"])
@login_required
def upload():
    user = current_user()
    sitename = clean_sitename(request.form.get("siteName"))
    file = request.files.get("siteFile")
    if len(sitename) < 3 or not file or file.filename == "":
        return jsonify({"ok": False, "error": "Need a site name (3+ chars) and a file."}), 400

    ext = os.path.splitext(file.filename)[1].lower()
    if ext not in ALLOWED_UPLOAD_EXT:
        return jsonify({"ok": False, "error": "Only .html or .zip files are allowed."}), 400

    db = get_db()
    existing = db.execute("SELECT * FROM sites WHERE sitename = ?", (sitename,)).fetchone()
    if existing and existing["owner_id"] != user["id"]:
        return jsonify({"ok": False, "error": "That site name is taken."}), 400

    site_dir = os.path.join(UPLOAD_DIR, sitename)
    if os.path.exists(site_dir):
        shutil.rmtree(site_dir)
    os.makedirs(site_dir)

    if ext == ".zip":
        tmp_zip = os.path.join(site_dir, "_upload.zip")
        file.save(tmp_zip)
        with zipfile.ZipFile(tmp_zip) as z:
            z.extractall(site_dir)
        os.remove(tmp_zip)
        if not os.path.exists(os.path.join(site_dir, "index.html")):
            return jsonify({"ok": False, "error": "Zip must contain an index.html at its root."}), 400
    else:
        file.save(os.path.join(site_dir, "index.html"))

    if not existing:
        db.execute(
            "INSERT INTO sites (owner_id, sitename, created_at) VALUES (?, ?, ?)",
            (user["id"], sitename, datetime.utcnow().isoformat()),
        )
        db.commit()

    url = url_for("serve_site", sitename=sitename, filename="", _external=True)
    return jsonify({"ok": True, "url": url})


@app.route("/api/delete", methods=["POST"])
@login_required
def delete_site():
    user = current_user()
    sitename = clean_sitename(request.form.get("siteName") or request.json.get("siteName") if request.is_json else request.form.get("siteName"))
    db = get_db()
    site = db.execute("SELECT * FROM sites WHERE sitename = ?", (sitename,)).fetchone()
    if not site or (site["owner_id"] != user["id"] and not user["is_admin"]):
        return jsonify({"ok": False, "error": "Not found."}), 404
    db.execute("DELETE FROM sites WHERE id = ?", (site["id"],))
    db.commit()
    shutil.rmtree(os.path.join(UPLOAD_DIR, sitename), ignore_errors=True)
    return jsonify({"ok": True})


@app.route("/api/user")
@login_required
def api_user():
    user = current_user()
    return jsonify({"username": user["username"], "is_admin": bool(user["is_admin"])})


# Serves hosted sites at /s/<sitename>/...
@app.route("/s/<sitename>/")
@app.route("/s/<sitename>/<path:filename>")
def serve_site(sitename, filename=""):
    sitename = clean_sitename(sitename)
    site_dir = os.path.join(UPLOAD_DIR, sitename)
    if not os.path.isdir(site_dir):
        abort(404)
    if filename == "":
        filename = "index.html"
    return send_from_directory(site_dir, filename)


# --------------------------------------------------------------------------
# Admin panel  ->  /admin
# --------------------------------------------------------------------------

@app.route("/admin/login", methods=["GET", "POST"])
def admin_login():
    if request.method == "GET":
        return render_template("admin_login.html", settings=get_settings())
    username = (request.form.get("username") or "").strip()
    password = request.form.get("password") or ""
    db = get_db()
    user = db.execute(
        "SELECT * FROM users WHERE username = ? AND is_admin = 1", (username,)
    ).fetchone()
    if not user or not check_password_hash(user["password_hash"], password):
        return render_template("admin_login.html", settings=get_settings(), error="Wrong admin username or password.")
    session["user_id"] = user["id"]
    return redirect(url_for("admin_panel"))


@app.route("/admin")
@admin_required
def admin_panel():
    db = get_db()
    users = db.execute("SELECT * FROM users ORDER BY created_at DESC").fetchall()
    sites = db.execute("""
        SELECT sites.*, users.username AS owner_name
        FROM sites JOIN users ON users.id = sites.owner_id
        ORDER BY sites.created_at DESC
    """).fetchall()
    stats = {
        "total_users": len(users),
        "total_sites": len(sites),
    }
    return render_template(
        "admin.html", user=current_user(), users=users, sites=sites,
        stats=stats, settings=get_settings()
    )


@app.route("/admin/settings", methods=["POST"])
@admin_required
def admin_update_settings():
    db = get_db()
    for key in ["site_name", "logo_url", "youtube_url", "tiktok_url", "facebook_url"]:
        val = request.form.get(key)
        if val is not None:
            db.execute("UPDATE settings SET value = ? WHERE key = ?", (val, key))
    db.commit()
    return redirect(url_for("admin_panel"))


@app.route("/admin/users/<int:user_id>/delete", methods=["POST"])
@admin_required
def admin_delete_user(user_id):
    db = get_db()
    target = db.execute("SELECT * FROM users WHERE id = ?", (user_id,)).fetchone()
    if target and not target["is_admin"]:
        sites = db.execute("SELECT sitename FROM sites WHERE owner_id = ?", (user_id,)).fetchall()
        for s in sites:
            shutil.rmtree(os.path.join(UPLOAD_DIR, s["sitename"]), ignore_errors=True)
        db.execute("DELETE FROM users WHERE id = ?", (user_id,))
        db.commit()
    return redirect(url_for("admin_panel"))


@app.route("/admin/sites/<int:site_id>/delete", methods=["POST"])
@admin_required
def admin_delete_site(site_id):
    db = get_db()
    site = db.execute("SELECT * FROM sites WHERE id = ?", (site_id,)).fetchone()
    if site:
        db.execute("DELETE FROM sites WHERE id = ?", (site_id,))
        db.commit()
        shutil.rmtree(os.path.join(UPLOAD_DIR, site["sitename"]), ignore_errors=True)
    return redirect(url_for("admin_panel"))


@app.route("/admin/change-password", methods=["POST"])
@admin_required
def admin_change_password():
    new_password = request.form.get("new_password") or ""
    if len(new_password) < 6:
        return redirect(url_for("admin_panel"))
    db = get_db()
    db.execute(
        "UPDATE users SET password_hash = ? WHERE id = ?",
        (generate_password_hash(new_password), current_user()["id"]),
    )
    db.commit()
    return redirect(url_for("admin_panel"))


if __name__ == "__main__":
    init_db()
    app.run(debug=True, host="0.0.0.0", port=int(os.environ.get("PORT", 5000)))
else:
    # also init when imported by a WSGI server (gunicorn etc.)
    init_db()
